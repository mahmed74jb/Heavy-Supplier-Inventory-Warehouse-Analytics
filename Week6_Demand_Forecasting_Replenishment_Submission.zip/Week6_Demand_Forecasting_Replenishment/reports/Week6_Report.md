# Week 6 Report — Demand Forecasting & Replenishment Planning

## 1. Objective
Create a clear, beginner-friendly baseline demand forecast from historical delivered sales and convert it into indicative replenishment planning measures.

## 2. Data used
- Sales order headers and sales order lines
- Product master (lead time, safety stock, criticality, reorder level)
- Inventory master (used for quality diagnostics only)
- Branch master (loaded for context)

Only sales lines attached to orders with status `Delivered` are included as realized demand.

## 3. Dataset snapshot
- Sales order headers: 20,000
- Delivered orders: 18,033
- Delivered sales lines: 117,656
- Unique products in product master: 30
- Monthly demand-history months: 72
- Sales header date range: 2019-01-01 to 2024-12-31

The product with the highest total delivered quantity in the available sales lines is `P029` (42,702 units). This is a historical total, not a forecast or profitability ranking.

## 4. Method
1. Convert order dates to dates and filter to `Delivered` orders.
2. Join sales lines to delivered order headers.
3. Aggregate quantities by product and calendar month.
4. Fill missing product-month combinations with zero demand.
5. Forecast each product's monthly demand using the mean of the latest three months available in the dataset.
6. Estimate daily demand as monthly forecast divided by 30.
7. Calculate indicative reorder point as `forecast daily demand × product lead time days + product safety stock`.
8. Backtest the three-month moving-average baseline using earlier months where enough history exists.

## 5. Inventory data-quality limitation
The provided `inventory_master.csv` has `current_stock > max_stock` in **180 of 180 records**. This is a systematic anomaly, not evidence that every item is genuinely overstocked. As a result, the report does not calculate an order quantity as `reorder point - current stock`; that would create misleading results until the stock figures are reconciled.

## 6. Recommendations
- Validate current stock quantities and units of measure with the data owner.
- Use the demand forecast to prioritize product reviews, especially high-criticality items with significant lead times.
- Before raising a purchase order, reconcile usable stock, allocated stock, open purchase orders, expected receipts, and transfers between branches.
- Compare the moving-average baseline with seasonal-naive and exponential-smoothing forecasts before operational use.
- Monitor forecast error monthly and update the baseline as new delivered sales arrive.

## 7. Limitations
- A three-month moving average is a simple baseline, not an advanced forecasting model.
- The forecast uses only the dataset's latest available three months, which may not represent seasonality or future conditions.
- Delivered order lines are used as a proxy for realized demand; returns/cancellations and stock-out-driven lost sales may not be fully represented.
- Reorder points depend on product master lead-time and safety-stock values being valid.
- No automatic purchase quantity is recommended while on-hand inventory values are unreliable.

## 8. Deliverables
- Notebook: `notebooks/Week6_Demand_Forecasting_Replenishment.ipynb`
- Reusable script: `src/demand_forecasting.py`
- Generated forecast CSV, backtest CSV, inventory quality CSV, and charts are written to `outputs/` after execution.
