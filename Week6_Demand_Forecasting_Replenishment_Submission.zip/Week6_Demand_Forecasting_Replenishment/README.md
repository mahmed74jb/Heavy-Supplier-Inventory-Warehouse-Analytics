# Week 6 — Demand Forecasting & Replenishment Planning

## Project
Heavy Supplier, Inventory & Warehouse Analytics

## Objective
Use historical delivered sales to estimate baseline product demand, calculate indicative lead-time demand and reorder points, backtest a simple moving-average method, and document stock-data quality limitations.

## Files
- `notebooks/Week6_Demand_Forecasting_Replenishment.ipynb` — main hands-on notebook
- `src/demand_forecasting.py` — reusable Python script
- `reports/Week6_Report.md` — findings, recommendations, and limitations
- `requirements.txt` — Python libraries
- `data/` — intentionally empty folder; place the dataset CSVs here locally
- `outputs/` — generated CSVs and charts will be saved here when the notebook runs

## Run it
1. Extract `HeavySuppliersWarehouseDatasets.zip` on your computer.
2. Copy the CSV files from `HeavySuppliersWarehouseDatasets/` into this project's `data/` folder.
3. Install libraries:
   ```bash
   pip install -r requirements.txt
   ```
4. Open the project folder in Jupyter and run `notebooks/Week6_Demand_Forecasting_Replenishment.ipynb` from top to bottom.
5. If needed, change `DATA_DIR = Path("data")` to the location of your CSV files.

The raw dataset is intentionally excluded from this submission ZIP. Do not publish it to a public GitHub repository unless the program owner authorizes that.

## Important interpretation note
The supplied inventory master has current stock above maximum stock in all 180 rows checked. Treat this as a data-quality issue requiring validation. The proposed reorder point is a demand-planning indicator; it is **not** a confirmed purchase quantity because the available stock-on-hand values are not reliable enough to use directly.

## GitHub upload
Upload the extracted folder contents into your existing repository under `week-06/`. Keep the folder names and notebook/report together. Then submit your repository link and choose Sprint/Week 6 in CadetX.
