from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Set this to the folder containing the supplied CSV files.
# Example: DATA_DIR = Path("../data") if you copied the CSVs into this project's data/ folder.
DATA_DIR = Path("../data")
OUTPUT_DIR = Path("../outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def load_csv(filename):
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(
            f"Cannot find {path}. Extract the supplied dataset ZIP and set DATA_DIR "
            "to the folder containing the CSV files. Do not publish the raw data unless authorized."
        )
    return pd.read_csv(path)

sales_h = load_csv("sales_orders_header.csv")
sales_l = load_csv("sales_orders_lines.csv")
products = load_csv("products.csv")
inventory = load_csv("inventory_master.csv")
branches = load_csv("branches.csv")

sales_h["order_date"] = pd.to_datetime(sales_h["order_date"], errors="coerce")
delivered = sales_h[sales_h["order_status"].astype(str).str.lower().eq("delivered")].copy()
sales = sales_l.merge(
    delivered[["so_id", "order_date", "branch_id"]],
    on="so_id", how="inner", validate="many_to_one"
)
sales["month"] = sales["order_date"].dt.to_period("M").dt.to_timestamp()

# Monthly demand series: only delivered order lines are treated as realized demand.
monthly = (
    sales.groupby(["product_id", "month"], as_index=False)["quantity"]
    .sum()
    .sort_values(["product_id", "month"])
)
all_months = pd.date_range(
    sales["month"].min(), sales["month"].max(), freq="MS"
)
product_ids = products["product_id"].dropna().unique()
full_index = pd.MultiIndex.from_product(
    [product_ids, all_months], names=["product_id", "month"]
)
monthly_full = (
    monthly.set_index(["product_id", "month"])
    .reindex(full_index, fill_value=0)
    .reset_index()
)

# Transparent baseline forecast: average monthly demand over the last 3 available months.
# This is a simple planning baseline, not a validated production forecasting model.
recent_months = sorted(monthly_full["month"].unique())[-3:]
forecast = (
    monthly_full[monthly_full["month"].isin(recent_months)]
    .groupby("product_id", as_index=False)["quantity"].mean()
    .rename(columns={"quantity": "forecast_monthly_qty"})
)
forecast["forecast_daily_qty"] = forecast["forecast_monthly_qty"] / 30.0
forecast = forecast.merge(
    products[[
        "product_id", "product_name", "category", "lead_time_days",
        "safety_stock", "reorder_level", "max_stock_level", "criticality_level"
    ]],
    on="product_id", how="left", validate="one_to_one"
)
forecast["lead_time_demand_qty"] = (
    forecast["forecast_daily_qty"] * forecast["lead_time_days"].fillna(0)
)
forecast["suggested_reorder_point_qty"] = (
    forecast["lead_time_demand_qty"] + forecast["safety_stock"].fillna(0)
).apply(np.ceil).astype(int)
forecast["suggested_monthly_order_qty"] = (
    forecast["forecast_monthly_qty"] * 1.0
).apply(np.ceil).astype(int)
forecast["forecast_monthly_qty"] = forecast["forecast_monthly_qty"].round(2)
forecast["forecast_daily_qty"] = forecast["forecast_daily_qty"].round(3)
forecast["lead_time_demand_qty"] = forecast["lead_time_demand_qty"].round(2)

# Inventory master is included as a data-quality diagnostic, not used to assert actual available stock.
inventory["current_stock"] = pd.to_numeric(inventory["current_stock"], errors="coerce")
inventory["max_stock"] = pd.to_numeric(inventory["max_stock"], errors="coerce")
inventory["stock_anomaly_flag"] = inventory["current_stock"] > inventory["max_stock"]
inventory_quality = inventory.groupby("branch_id", as_index=False).agg(
    inventory_rows=("product_id", "size"),
    current_stock_above_max=("stock_anomaly_flag", "sum")
)
inventory_quality["share_above_max_pct"] = (
    100 * inventory_quality["current_stock_above_max"] / inventory_quality["inventory_rows"]
).round(1)

# Evaluation: a 3-month moving-average one-step-ahead baseline for products with enough history.
# MAE and WAPE are reported at aggregate monthly level; zeros are retained in the panel.
wide = monthly_full.pivot(index="month", columns="product_id", values="quantity").fillna(0).sort_index()
eval_rows = []
if len(wide.index) >= 6:
    for i in range(3, len(wide.index)):
        actual = wide.iloc[i]
        pred = wide.iloc[i-3:i].mean(axis=0)
        eval_rows.append({
            "month": wide.index[i],
            "mae_qty_per_product": float((actual - pred).abs().mean()),
            "actual_total_qty": float(actual.sum()),
            "forecast_total_qty": float(pred.sum()),
            "absolute_error_total_qty": float((actual.sum() - pred.sum()).__abs__())
        })
evaluation = pd.DataFrame(eval_rows)
if not evaluation.empty:
    total_actual = evaluation["actual_total_qty"].sum()
    wape = evaluation["absolute_error_total_qty"].sum() / total_actual * 100 if total_actual else np.nan
    print(f"Backtest months: {len(evaluation)}")
    print(f"Aggregate WAPE (%): {wape:.2f}" if pd.notna(wape) else "Aggregate WAPE unavailable (zero actual demand)")
else:
    wape = np.nan
    print("Not enough monthly history for a 3-month backtest.")

forecast = forecast.sort_values(["forecast_monthly_qty", "criticality_level"], ascending=[False, True])
forecast.to_csv(OUTPUT_DIR / "product_demand_forecast.csv", index=False)
inventory_quality.to_csv(OUTPUT_DIR / "inventory_data_quality_by_branch.csv", index=False)
evaluation.to_csv(OUTPUT_DIR / "forecast_backtest.csv", index=False)

print("Delivered orders:", len(delivered))
print("Delivered sales lines:", len(sales))
print("Product count:", products["product_id"].nunique())
print("Months in demand history:", len(all_months))
print("Inventory records above max_stock:", int(inventory["stock_anomaly_flag"].sum()), "of", len(inventory))
display(forecast.head(10))
display(inventory_quality)
if not evaluation.empty:
    display(evaluation.tail())

# Visualize total monthly demand and the highest-demand products.
monthly_total = monthly_full.groupby("month", as_index=False)["quantity"].sum()
plt.figure(figsize=(12, 5))
plt.plot(monthly_total["month"], monthly_total["quantity"], marker="o")
plt.title("Monthly Delivered Demand — All Products")
plt.xlabel("Month")
plt.ylabel("Quantity")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "monthly_demand_trend.png", dpi=150)
plt.show()

top_products = forecast.head(10).sort_values("forecast_monthly_qty")
plt.figure(figsize=(10, 6))
plt.barh(top_products["product_name"], top_products["forecast_monthly_qty"])
plt.title("Top 10 Products by Baseline Monthly Demand Forecast")
plt.xlabel("Forecast quantity per month")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "top10_demand_forecast.png", dpi=150)
plt.show()
