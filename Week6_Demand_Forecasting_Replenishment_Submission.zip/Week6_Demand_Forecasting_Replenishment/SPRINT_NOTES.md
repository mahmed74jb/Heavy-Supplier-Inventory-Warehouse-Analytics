# CadetX Sprint 6 Submission Notes

**Sprint title:** Demand Forecasting & Replenishment Planning

## What I completed
- Prepared historical delivered sales as a product-month demand series.
- Built a transparent 3-month moving-average demand baseline.
- Calculated indicative lead-time demand and reorder-point quantities.
- Backtested the baseline where sufficient monthly history exists.
- Audited inventory stock values and documented a major data-quality limitation.
- Prepared recommendations and a reusable notebook/script.

## Before running
Copy the CSV files from the provided dataset ZIP into this project's `data/` folder. The raw data is not bundled here to avoid public redistribution.

## Upload checklist
- [ ] Extract the ZIP.
- [ ] Upload the folder contents to GitHub under `week-06/`.
- [ ] Keep the notebook, report, README, script, and requirements file.
- [ ] Do not upload raw dataset files publicly unless authorized.
- [ ] Submit the GitHub repository link in CadetX and select Sprint/Week 6.
