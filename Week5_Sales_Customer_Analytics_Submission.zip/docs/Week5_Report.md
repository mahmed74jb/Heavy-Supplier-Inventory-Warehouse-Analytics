# Week 5 Report — Sales & Customer Analytics

## 1. Objective
Analyse realised sales using delivered orders, understand customer activity and value, review monthly sales trends, and identify top products and branches.

## 2. Method
- Only sales orders with `order_status = Delivered` are treated as realised sales for this analysis.
- Customer delivered-order value is the sum of the selected order-value field for delivered orders.
- Customer segments use quartiles among active customers: High Value at/above the 75th percentile, Low Value at/below the 25th percentile, and Mid Value between those thresholds. These are exploratory segments, not permanent business rules.
- Product line sales are restricted to lines belonging to delivered orders.

## 3. Key Findings
- Customer master records: 500
- Sales order headers: 20000
- Delivered orders: 18033
- Total delivered sales value: 22,958,987,430.00
- Customers with at least one delivered order: 500
- Customers without delivered orders in this dataset: 0

### Top customers by delivered-order value
- C0153: 56 delivered orders; value 84,966,970.00
- C0288: 55 delivered orders; value 76,291,160.00
- C0483: 47 delivered orders; value 75,352,940.00
- C0475: 55 delivered orders; value 74,442,140.00
- C0495: 48 delivered orders; value 74,165,320.00

### Customer segments among active customers
- Mid Value: 250 active customers
- High Value: 125 active customers
- Low Value: 125 active customers

## 4. Monthly Trend
See `outputs/monthly_delivered_sales.csv` for delivered order count, distinct customers and sales value by month.

## 5. Product and Branch Performance
- `outputs/top_30_product_performance.csv` ranks products by delivered-order line sales value and units sold.
- `outputs/branch_sales_performance.csv` summarises delivered orders, distinct customers and sales value by branch.

## 6. Data Quality
See `outputs/sales_customer_data_quality_checks.csv`. These checks cover customer/order references and customers with no delivered orders.

## 7. Recommendations
1. Review high-value customers for retention and service-level opportunities.
2. Investigate customers without delivered orders; lack of delivered sales does not prove a customer is inactive or lost without considering date range and other statuses.
3. Use monthly sales trends for planning, while checking seasonality and date coverage.
4. Prioritise top-selling products for demand planning and availability monitoring.
5. Avoid treating exploratory quartile segments as fixed customer tiers without business validation.

## 8. Deliverables
- `notebooks/Week5_Sales_Customer_Analytics.ipynb`
- `outputs/customer_sales_kpis.csv`
- `outputs/active_customer_segments.csv`
- `outputs/customers_without_delivered_orders.csv`
- `outputs/monthly_delivered_sales.csv`
- `outputs/top_30_product_performance.csv`
- `outputs/branch_sales_performance.csv`
- `outputs/sales_customer_data_quality_checks.csv`
