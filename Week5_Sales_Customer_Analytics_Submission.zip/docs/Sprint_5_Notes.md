# Sprint 5 Notes — Sales & Customer Analytics

## Goal
Measure realised sales activity, customer value and product/branch sales patterns.

## Completed
- Delivered sales analysis
- Customer order/value KPIs
- Exploratory customer segmentation
- Monthly delivered sales trend
- Top product performance
- Branch sales performance
- Data-quality checks

## KPI definitions
- Delivered Orders = distinct sales order IDs marked Delivered
- Customer Delivered Value = sum of order value for delivered orders
- Average Order Value = delivered-order value / delivered order count
- Customer segments = quartile-based exploratory groups among active customers

## Limitations
Customers without delivered orders may have other statuses or may fall outside the observed date window. Customer segments are descriptive and should be validated before use in business policy.
