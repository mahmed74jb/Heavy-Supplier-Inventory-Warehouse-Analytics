# GitHub Upload Guide — Week 5

Inside your existing repository, create `week-05` and upload the contents of this submission.

```text
week-05/
├── README.md
├── notebooks/
│   └── Week5_Sales_Customer_Analytics.ipynb
├── docs/
│   ├── Week5_Report.md
│   ├── Sprint_5_Notes.md
│   └── GitHub_Upload_Guide.md
└── outputs/
    ├── customer_sales_kpis.csv
    ├── active_customer_segments.csv
    ├── customers_without_delivered_orders.csv
    ├── monthly_delivered_sales.csv
    ├── top_30_product_performance.csv
    ├── branch_sales_performance.csv
    └── sales_customer_data_quality_checks.csv
```

CadetX Sprint Number: **5**. Avoid uploading raw source datasets to a public repository unless CadetX has authorised redistribution.
