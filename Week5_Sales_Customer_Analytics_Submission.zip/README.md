# Week 5 — Sales & Customer Analytics

This folder contains the Week 5 analysis for the Heavy Supplier, Inventory & Warehouse Analytics project.

## Contents
- `notebooks/` — Jupyter analysis notebook
- `docs/` — report, sprint notes and upload guide
- `outputs/` — customer, sales, product, branch and data-quality outputs

## Method
Only sales orders marked Delivered are treated as realised sales. Customer segments use exploratory quartile thresholds and are not permanent business classifications.
