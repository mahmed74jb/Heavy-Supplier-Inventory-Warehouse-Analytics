from pathlib import Path
import pandas as pd
import numpy as np
DATA_DIR=Path("../data")
OUT=Path("../outputs"); OUT.mkdir(parents=True,exist_ok=True)
def load(n):
    p=DATA_DIR/n
    if not p.exists(): raise FileNotFoundError(f"Copy CSV files into {DATA_DIR.resolve()}")
    return pd.read_csv(p)
sh=load("sales_orders_header.csv"); sl=load("sales_orders_lines.csv"); pr=load("products.csv"); inv=load("inventory_master.csv")
sh["order_date"]=pd.to_datetime(sh["order_date"],errors="coerce")
d=sh[sh["order_status"].astype(str).str.lower().eq("delivered")]
s=sl.merge(d[["so_id","order_date"]],on="so_id",how="inner",validate="many_to_one")
s["month"]=s["order_date"].dt.to_period("M").dt.to_timestamp()
m=s.groupby(["product_id","month"],as_index=False)["quantity"].sum()
months=pd.date_range(s["month"].min(),s["month"].max(),freq="MS")
idx=pd.MultiIndex.from_product([pr["product_id"].dropna().unique(),months],names=["product_id","month"])
panel=m.set_index(["product_id","month"]).reindex(idx,fill_value=0).reset_index()
w=panel.pivot(index="month",columns="product_id",values="quantity").fillna(0).sort_index()
rows=[]
for i in range(3,len(w)):
    a=w.iloc[i]; p=w.iloc[i-3:i].mean(axis=0)
    rows.append({"month":w.index[i],"model":"3-month moving average","mae":float((a-p).abs().mean()),"rmse":float(np.sqrt(((a-p)**2).mean()))})
    if i>=12:
        p=w.iloc[i-12]
        rows.append({"month":w.index[i],"model":"seasonal naive","mae":float((a-p).abs().mean()),"rmse":float(np.sqrt(((a-p)**2).mean()))})
pd.DataFrame(rows).to_csv(OUT/"forecast_backtest_detail.csv",index=False)
recent=sorted(panel["month"].unique())[-3:]
f=panel[panel["month"].isin(recent)].groupby("product_id",as_index=False)["quantity"].mean().rename(columns={"quantity":"baseline_monthly_demand"})
f=f.merge(pr[["product_id","product_name","category","lead_time_days","safety_stock","criticality_level"]],on="product_id",how="left")
f["daily_demand"]=f["baseline_monthly_demand"]/30
f["lead_time_demand"]=f["daily_demand"]*pd.to_numeric(f["lead_time_days"],errors="coerce").fillna(0)
f["indicative_reorder_point"]=np.ceil(f["lead_time_demand"]+pd.to_numeric(f["safety_stock"],errors="coerce").fillna(0))
dmax=f["baseline_monthly_demand"].max(); lmax=f["lead_time_demand"].max()
f["priority_score"]=(.45*f["baseline_monthly_demand"]/dmax if dmax else 0)+(.35*f["lead_time_demand"]/lmax if lmax else 0)
crit=f["criticality_level"].astype(str).str.lower()
f["priority_score"]+=np.select([crit.str.contains("high|critical"),crit.str.contains("medium")],[.25,.10],default=0)
f.sort_values("priority_score",ascending=False).to_csv(OUT/"product_inventory_priority.csv",index=False)
inv["above_max"]=pd.to_numeric(inv["current_stock"],errors="coerce")>pd.to_numeric(inv["max_stock"],errors="coerce")
inv.groupby("branch_id").agg(inventory_rows=("product_id","size"),current_stock_above_max=("above_max","sum")).to_csv(OUT/"inventory_quality_by_branch.csv")
print("Week 7 outputs saved to",OUT.resolve())
