# CadetX Sprint 7 Submission Notes

**Sprint title:** Forecast Accuracy & Inventory Optimization

## Completed
- Backtested a 3-month moving-average baseline and seasonal-naive baseline where enough history exists.
- Calculated MAE and RMSE.
- Created a product review priority score using demand, lead time, and criticality.
- Audited inventory stock-vs-maximum anomalies.
- Documented limitations and recommendations.

## Upload checklist
- [ ] Extract the ZIP.
- [ ] Upload contents to existing GitHub repository under `week-07/`.
- [ ] Keep notebook, report, README, script, and requirements together.
- [ ] Do not upload raw dataset publicly unless authorized.
- [ ] Submit the repository link in CadetX and select Sprint/Week 7.
