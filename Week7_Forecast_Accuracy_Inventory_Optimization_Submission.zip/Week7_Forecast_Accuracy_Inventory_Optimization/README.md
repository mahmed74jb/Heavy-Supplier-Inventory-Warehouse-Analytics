# Week 7 — Forecast Accuracy & Inventory Optimization

## Files
- `notebooks/Week7_Forecast_Accuracy_Inventory_Optimization.ipynb`
- `src/week7_analysis.py`
- `reports/Week7_Report.md`
- `requirements.txt`
- `SPRINT_NOTES.md`

## Run
1. Extract the supplied dataset ZIP.
2. Copy the CSV files into `data/`.
3. Run `pip install -r requirements.txt`.
4. Open the notebook and run cells from top to bottom.

Raw dataset files are intentionally excluded from this ZIP. Do not publish them unless authorized.
