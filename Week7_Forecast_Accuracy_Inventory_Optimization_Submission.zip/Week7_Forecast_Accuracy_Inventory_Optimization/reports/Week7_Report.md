# Week 7 Report — Forecast Accuracy & Inventory Optimization

## Objective
Evaluate baseline forecasts, compare forecast error, and prioritize products for inventory review.

## Dataset snapshot
- Sales order headers: 20,000
- Delivered orders: 18,033
- Delivered sales lines: 117,656
- Product master products: 30
- Monthly history: 72 months
- Total delivered quantity: 1,234,939
- Sales header date range: 2019-01-01 to 2024-12-31

## Method
Filter to Delivered orders; aggregate product-month demand; fill missing months with zero; backtest a 3-month moving average and seasonal-naive forecast when 12 months of history exist; compare MAE/RMSE; create an explainable priority score from normalized demand, lead-time demand, and criticality.

## Inventory data-quality issue
`current_stock > max_stock` occurs in 180 of 180 inventory rows. This is a systematic anomaly that needs validation; it is not proof that every product is actually overstocked. For this reason, the analysis does not use this field to calculate actual order quantities.

## Recommendations
- Use measured backtest metrics to choose a forecast baseline.
- Review high-priority products for demand, criticality, and supplier lead time.
- Validate stock balances, units of measure, allocations, open POs, and expected receipts before purchasing.
- Recheck forecast errors each month and refine models as more data becomes available.

## Limitations
The models are simple baselines and may miss seasonality, promotions, and lost sales during stockouts. Priority score is a screening aid, not an automated purchase recommendation.
