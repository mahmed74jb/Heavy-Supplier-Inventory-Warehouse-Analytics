# Week 1 Report — Data Profiling, Cleaning & Initial KPIs

## 1. Project purpose
The dataset is designed for analysis of heavy suppliers, products, inventory and warehouse operations. Week 1 establishes the data foundation before deeper product, inventory, supplier and warehouse analysis.

## 2. Dataset inventory

| File | Rows | Columns | Missing cells | Exact duplicate rows |
|---|---:|---:|---:|---:|
| branches.csv | 6 | 13 | 0 | 0 |\n| customers.csv | 500 | 15 | 0 | 0 |\n| inventory_master.csv | 180 | 11 | 0 | 0 |\n| invoices.csv | 18,033 | 10 | 0 | 0 |\n| payments.csv | 19,257 | 5 | 0 | 0 |\n| products.csv | 30 | 23 | 0 | 0 |\n| purchase_orders_header.csv | 24,000 | 10 | 2,370 | 0 |\n| purchase_orders_lines.csv | 155,495 | 9 | 0 | 0 |\n| sales_orders_header.csv | 20,000 | 11 | 0 | 0 |\n| sales_orders_lines.csv | 130,402 | 9 | 0 | 0 |\n| stock_ledger.csv | 237,230 | 9 | 0 | 0 |\n| suppliers.csv | 8 | 12 | 0 | 0 |\n
## 3. Relationships
The main relationship structure is:

- `branches.branch_id` → customers, inventory, sales orders, purchase orders, invoices, stock ledger
- `products.product_id` → inventory, sales-order lines, purchase-order lines, stock ledger
- `customers.customer_id` → sales orders and invoices
- `suppliers.supplier_id` → purchase-order headers
- `sales_orders_header.so_id` → sales-order lines and invoices
- `purchase_orders_header.po_id` → purchase-order lines
- `invoices.invoice_id` → payments
- `inventory_master` uses the compound key `product_id + branch_id`

All tested foreign-key relationships returned **0 unmatched rows**.

## 4. Data-quality findings

### Missing values
Only `purchase_orders_header.received_date` has missing values: **2,370** rows. The purchase-order status distribution shows **2,370 cancelled** POs, so these missing received dates are consistent with orders that were cancelled rather than received. They should remain missing unless the data owner provides a business rule for them.

### Duplicate rows vs duplicate IDs
There are no exact duplicate rows in the 12 CSV files. However:
- `invoices.csv`: **196 invoice IDs** are repeated; the maximum repetition is 3.
- `payments.csv`: **201 payment IDs** are repeated; the maximum repetition is 3.

The repeated IDs are attached to different transaction records, so they should not be silently deduplicated. A transaction-key/data-generation issue should be resolved before using these fields as unique identifiers.

### Numeric/business-rule validation
`inventory_master.current_stock` is between **88,853 and 121,013**, while `max_stock` is between **131 and 582**. Therefore all 180 inventory records have `current_stock > max_stock`. This makes normal stock-utilisation/overstock calculations unreliable until the scale or business meaning of `current_stock` is confirmed.

### Header-to-line reconciliation
Purchase-order header totals reconcile to purchase-order line totals, and sales-order header totals reconcile to sales-order line totals, within normal floating-point rounding tolerance.

### Standardisation
`branches.warehouse_capacity` is stored as text with a unit (for example, `45230 sqft`). A numeric `capacity_sqft` field is created for analysis.

## 5. Initial KPI snapshot

- Branches: **{len(branches)}**
- Customers: **{len(dfs["customers.csv"]):,}**
- Products: **{len(products)}**
- Suppliers: **{len(suppliers)}**
- Sales orders: **{len(so):,}**
- Delivered sales orders: **{int((so.order_status=="Delivered").sum()):,}**
- Cancelled sales orders: **{int((so.order_status=="Cancelled").sum()):,}**
- Delivered sales-order value: **{so.loc[so.order_status=="Delivered","total_order_value"].sum():,.2f}**
- Purchase orders: **{len(po):,}**
- Received purchase orders: **{int((po.po_status=="Received").sum()):,}**
- Cancelled purchase orders: **{int((po.po_status=="Cancelled").sum()):,}**
- Received purchase cost: **{po.loc[po.po_status=="Received","total_cost"].sum():,.2f}**
- Invoices: **{len(inv):,}**
- Paid invoices: **{int((inv.payment_status=="Paid").sum()):,}**
- Partially paid invoices: **{int((inv.payment_status=="Partially Paid").sum()):,}**
- Unpaid invoices: **{int((inv.payment_status=="Unpaid").sum()):,}**
- Stock ledger movements: **{len(stock):,}**

## 6. Initial KPI definitions for later sprints

| KPI | Definition | Main tables |
|---|---|---|
| Sales order delivery rate | Delivered orders / total sales orders | sales_orders_header |
| Sales cancellation rate | Cancelled orders / total sales orders | sales_orders_header |
| Sales value | Sum of order value for selected order status | sales_orders_header |
| Purchase receipt rate | Received POs / total POs | purchase_orders_header |
| Supplier on-time rate | Received POs with actual receipt on/before expected date / received POs | purchase_orders_header |
| Average supplier delay | Average(received date − expected date) for received POs | purchase_orders_header |
| Inventory stock vs reorder | Current stock compared with reorder level | inventory_master |
| Inventory stock vs safety | Current stock compared with safety stock | inventory_master |
| Inventory utilisation | Current stock / max stock | inventory_master |
| Customer outstanding balance | Sum of current customer balances | customers |
| Invoice payment mix | Paid / partially paid / unpaid invoice counts | invoices |
| Warehouse operating surplus | Monthly revenue − monthly operating cost | branches |

**Important:** inventory utilisation and stock-risk KPIs should not be treated as reliable until the `current_stock` vs `max_stock` inconsistency is resolved.

## 7. Week 1 analysis questions
1. Which branches have the highest sales value and order volume?
2. Which branches have the highest market demand index?
3. Which products generate the highest sales quantity and value?
4. Which products are most critical but show weak inventory availability?
5. Which suppliers have the best combination of reliability, lead time and on-time delivery?
6. Which suppliers contribute the largest purchase spend?
7. Which products/categories have high purchase frequency or long lead times?
8. What are the main stock movement patterns (IN, OUT, ADJUSTMENT) by branch and product?
9. What is the customer payment-status mix and outstanding balance exposure?
10. Which data-quality issues must be resolved before advanced forecasting and inventory optimisation?

## 8. Week 1 conclusion
The dataset is structurally rich and the tested table relationships are usable for downstream analysis. The most important issues to carry forward are the repeated invoice/payment IDs and the major inventory-scale inconsistency. Week 1 should therefore be considered a **foundation and validation sprint**, not the final inventory-optimisation analysis.

The next sprint can safely build on validated sales, purchase, supplier, customer and stock-movement relationships while treating the flagged inventory fields with caution.
