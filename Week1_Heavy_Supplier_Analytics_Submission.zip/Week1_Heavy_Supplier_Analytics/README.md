# Week 1 — Heavy Supplier, Inventory & Warehouse Analytics

This folder contains the Week 1 submission package for the CadetX applied work-experience project.

## Week 1 objectives completed
- Data profiling and structure review
- Missing-value and duplicate-key checks
- Referential-integrity checks
- Initial data-quality observations
- Initial KPI definitions and calculations
- Data dictionary
- Initial analysis questions
- Reproducible Python/Jupyter notebook
- Branch and supplier KPI outputs

## Dataset
The project contains 12 CSV tables covering branches, customers, products, inventory, sales, purchases, invoices, payments, stock movements and suppliers.

## Important data-quality observations
1. `purchase_orders_header.csv` has 2,370 missing `received_date` values. These rows are associated with cancelled purchase orders, so the missing date is logically explainable and should not automatically be filled.
2. `invoices.csv` contains repeated `invoice_id` values across different invoice records, and `payments.csv` contains repeated `payment_id` values across different payment records. These are data-quality issues that should be investigated before using those IDs as unique transaction keys.
3. All tested foreign-key relationships matched their parent tables.
4. Purchase-order and sales-order header totals reconcile to their line-level totals within floating-point rounding tolerance.
5. `inventory_master.csv` has `current_stock` values far above `max_stock` for all 180 product-branch records. This is a critical validation issue; the values should be confirmed with the data owner before calculating inventory-utilisation or overstock KPIs.
6. Warehouse capacity is stored as text such as `45230 sqft`; the notebook converts it to a numeric `capacity_sqft` field for analysis.

## Recommended GitHub structure
```text
week1/
├── README.md
├── notebooks/
│   └── Week1_Data_Profiling.ipynb
├── docs/
│   ├── Week1_Report.md
│   └── data_dictionary.csv
├── outputs/
│   ├── data_quality_profile.csv
│   ├── kpi_summary.csv
│   ├── branch_kpis.csv
│   ├── supplier_kpis.csv
│   └── inventory_quality_flags.csv
└── data/
    └── *.csv
```

For a public GitHub repository, do not publish raw data if the programme/provider has not authorised it.
