# Week 3 Report — Supplier & Procurement Analytics

## 1. Objective
Week 3 analyses supplier activity and procurement patterns using purchase-order headers, purchase-order lines, supplier master data and product data.

## 2. Scope
- Supplier purchasing activity
- Purchase-order volume and status
- Procurement value and units ordered
- Supplier concentration
- Monthly procurement trend
- Top procured products
- Procurement data-quality checks

## 3. Method
Procurement value is calculated as:

`Procurement Value = Quantity × Unit Price`

Supplier share is calculated as supplier procurement value divided by total procurement value.

No supplier performance score is created for delivery, lead time or quality because such a score would require appropriate fields and definitions in the supplied data.

## 4. Data Quality
The Week 3 checks cover supplier/PO relationships and missing or zero quantity/unit-price values. See `outputs/procurement_data_quality_checks.csv`.

## 5. Supplier Concentration
Top suppliers by procurement value:
- Tianjin OEM Supplies: procurement value 44,748,497,243.67 (12.9% of total)
- Shenzhen OEM Supplies: procurement value 43,664,270,006.09 (12.6% of total)
- Shanghai Distributor Supplies: procurement value 43,657,994,600.35 (12.6% of total)

A high share of procurement value means purchasing is concentrated financially. It should be investigated together with supply risk, alternatives, contract terms and operational requirements rather than being treated as a performance failure.

## 6. Purchase Order Status
- Cancelled: 2370 purchase orders
- Received: 21630 purchase orders

## 7. Procurement Trend
The monthly procurement output is provided in `outputs/monthly_procurement_trend.csv`. It can be used to identify months with higher purchasing volume/value and support procurement planning.

## 8. Top Procured Products
`outputs/top_20_procured_products.csv` lists the products with the highest procurement value.

## 9. Key Findings
1. Supplier procurement concentration can be quantified using procurement-value share.
2. Purchase-order activity can be monitored using PO count, units ordered and procurement value.
3. Monthly procurement trends provide a baseline for future supplier and demand planning.
4. Top procured products identify categories/items with greater purchasing exposure.
5. Supplier delivery/quality performance should not be inferred from procurement value alone.

## 10. Recommendations
- Review high-concentration suppliers for continuity and alternative-source planning.
- Monitor procurement value and order volumes monthly.
- Link future supplier analysis with delivery dates, promised dates, lead times, received quantities and quality/defect data if available.
- Use top-procured products as candidates for procurement planning and supplier negotiation analysis.

## 11. Files
- `notebooks/Week3_Supplier_Procurement_Analytics.ipynb`
- `outputs/supplier_kpis.csv`
- `outputs/monthly_procurement_trend.csv`
- `outputs/purchase_order_status_summary.csv`
- `outputs/top_20_procured_products.csv`
- `outputs/supplier_category_procurement.csv`
- `outputs/procurement_data_quality_checks.csv`
