# GitHub Upload Guide — Week 3

Inside your existing repository, create a folder:

`week-03`

Upload these items into it:

```text
week-03/
├── README.md
├── notebooks/
│   └── Week3_Supplier_Procurement_Analytics.ipynb
├── docs/
│   ├── Week3_Report.md
│   └── Sprint_3_Notes.md
└── outputs/
    ├── supplier_kpis.csv
    ├── monthly_procurement_trend.csv
    ├── purchase_order_status_summary.csv
    ├── top_20_procured_products.csv
    ├── supplier_category_procurement.csv
    └── procurement_data_quality_checks.csv
```

If the CadetX portal asks for the sprint number, use **3** for Week 3.

Do not upload raw source data to a public repository unless CadetX has authorised public redistribution.
