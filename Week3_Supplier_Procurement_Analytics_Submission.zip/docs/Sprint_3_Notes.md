# Sprint 3 Notes

## Sprint
3 — Supplier & Procurement Analytics

## Goal
Understand supplier purchasing activity, procurement concentration and purchase-order patterns.

## Completed
- Supplier KPI analysis
- Procurement value calculation
- Supplier concentration analysis
- PO status summary
- Monthly procurement trend
- Top procured products
- Procurement data-quality checks

## Main KPI definitions
- Purchase Orders = distinct PO IDs
- Units Ordered = sum of PO line quantities
- Procurement Value = quantity × unit price
- Procurement Share = supplier procurement value / total procurement value

## Collaboration note
The project is being completed individually. Results are prepared in a GitHub-ready structure for weekly submission.

## Next
Week 4 can extend into warehouse/branch efficiency and inventory utilisation, depending on the programme task sequence.
