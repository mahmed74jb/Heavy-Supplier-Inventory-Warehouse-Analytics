# Week 3 — Supplier & Procurement Analytics

This folder contains the complete Week 3 work for the Heavy Supplier, Inventory & Warehouse Analytics project.

## Contents
- `notebooks/` — analysis notebook
- `docs/` — Week 3 report and sprint notes
- `outputs/` — supplier, procurement, trend and data-quality outputs
- `data/` — local working copy of the source dataset used to generate the outputs

## Core KPIs
- Purchase orders
- Units ordered
- Procurement value
- Supplier procurement share
- Monthly procurement value

## Important note
Supplier procurement concentration is descriptive. It is not automatically a supplier-performance rating. Delivery, lead-time and quality performance require appropriate source fields.
