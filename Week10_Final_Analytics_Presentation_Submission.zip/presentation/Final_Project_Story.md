# Final Project Story — Heavy Supplier, Inventory & Warehouse Analytics

## Slide 1 — Title
**Heavy Supplier, Inventory & Warehouse Analytics**  
A practical analytics project covering product inventory, supplier procurement, warehouse/branch operations, customer sales, demand forecasting, and executive reporting.

## Slide 2 — Business Questions
- Which products and categories show stronger or weaker delivered demand?
- How can inventory records be reviewed for replenishment and stock exceptions?
- What does the procurement dataset show about purchase-order activity and estimated line value?
- How can branch, customer, and sales metrics be presented consistently?
- Which data limitations should decision-makers resolve before operational use?

## Slide 3 — Data Overview
The project uses linked CSV tables for branches, customers, products, inventory, suppliers, purchase orders, sales orders, stock ledger, invoices, and payments. Validate keys, date fields, status values, duplicate IDs, and missing values before drawing conclusions.

## Slide 4 — Product & Inventory Analysis
- Compare delivered product demand and category performance.
- Identify low-activity products for review, not automatic discontinuation.
- Flag inventory rows where current stock exceeds max stock.
- Treat this flag as a data-quality/business-rule exception requiring validation.

## Slide 5 — Supplier & Procurement Analysis
- Summarize purchase-order counts and status distribution.
- Estimate procurement line value using quantity × unit price where fields are available.
- Use supplier comparisons as descriptive evidence, not as a definitive supplier ranking without validated context.
- Do not claim on-time delivery without reliable promised and actual receipt dates.

## Slide 6 — Warehouse & Branch Analysis
- Compare available branch and stock-ledger activity.
- Confirm that branch IDs and event dates are valid before creating operational trend charts.
- Investigate unusual stock movements and reconcile opening stock, movements, and closing stock where possible.

## Slide 7 — Sales & Customer Analysis
- Use Delivered order status for realized-sales views where the source supports it.
- Compare delivered order counts, units, and customer activity.
- Clearly label sales value estimates if discounts, taxes, returns, or cancellations are not represented.

## Slide 8 — Demand Forecasting & Replenishment
- Present moving-average and seasonal-naive baselines only where sufficient history exists.
- Report backtest metrics such as MAE and RMSE with the test period and forecast horizon.
- Treat reorder points as planning estimates; validate lead times, service levels, and stock policies before operational adoption.

## Slide 9 — Executive KPI Dashboard
Recommended KPIs:
- Delivered sales orders and units
- Estimated delivered sales value (with caveat)
- Inventory records above max stock
- Purchase-order count and status mix
- Branch count and validated stock movement indicators
- Forecast error by model and test period

## Slide 10 — Key Risks & Data Quality
- Current stock exceeding max stock appears in the provided inventory master and should be investigated.
- Repeated invoice/payment IDs must not be blindly deduplicated; confirm their intended row grain.
- Estimated PO line value is not the same as invoiced or paid spend.
- Supplier on-time delivery is not measurable unless actual and promised dates are available and reliable.
- Low recorded sales do not automatically mean dead stock.

## Slide 11 — Recommendations
1. Resolve inventory max-stock rule and verify the affected records.
2. Establish consistent KPI definitions and data-grain documentation.
3. Reconcile PO line estimates to invoices and payments before reporting actual spend.
4. Improve date capture for supplier lead-time and on-time delivery analysis.
5. Use forecast outputs as decision support, with a human review before replenishment.
6. Publish an access-controlled dashboard and refresh it on a documented schedule.

## Slide 12 — Next Steps
- Review assumptions with the project mentor or business stakeholder.
- Validate KPI totals against source reports.
- Build the dashboard in the organization-approved BI tool.
- Document ownership, refresh cadence, and exception-handling process.

## Speaker note
Keep the presentation evidence-led: distinguish observed data, calculated estimates, assumptions, and recommendations. Do not claim cost savings, forecast accuracy, or operational improvement unless the analysis directly measures it.
