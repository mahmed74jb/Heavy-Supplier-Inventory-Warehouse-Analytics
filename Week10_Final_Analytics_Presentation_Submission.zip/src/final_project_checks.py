from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

EXPECTED = [
    "branches.csv", "customers.csv", "inventory_master.csv", "invoices.csv",
    "payments.csv", "products.csv", "purchase_orders_header.csv",
    "purchase_orders_lines.csv", "sales_orders_header.csv",
    "sales_orders_lines.csv", "stock_ledger.csv", "suppliers.csv"
]

def main():
    rows = []
    for filename in EXPECTED:
        path = DATA / filename
        if not path.exists():
            rows.append({"file": filename, "present": False, "rows": None, "columns": None, "status": "Missing"})
            continue
        try:
            df = pd.read_csv(path)
            rows.append({"file": filename, "present": True, "rows": len(df), "columns": len(df.columns), "status": "Loaded"})
        except Exception as exc:
            rows.append({"file": filename, "present": True, "rows": None, "columns": None, "status": f"Read error: {exc}"})
    report = pd.DataFrame(rows)
    report.to_csv(OUT / "final_data_inventory.csv", index=False)
    print(report.to_string(index=False))
    print(f"\\nReport saved to: {OUT / 'final_data_inventory.csv'}")

if __name__ == "__main__":
    main()
