# Executive Recommendations

## Priority 1 — Validate inventory policy
Investigate why current stock exceeds max stock in the supplied inventory master. Confirm the meaning, unit, and validity of both fields before classifying records as overstock.

## Priority 2 — Establish trusted financial metrics
Procurement line value calculated as quantity × unit price is an estimate. Reconcile it to invoice and payment tables and document whether taxes, discounts, returns, and currency are included.

## Priority 3 — Improve supplier performance evidence
Capture or validate promised and actual receipt dates, partial delivery rules, and cancellation handling before calculating on-time delivery or lead-time KPIs.

## Priority 4 — Govern shared KPI definitions
Document each KPI's formula, source tables, row grain, filters, date basis, owner, and refresh frequency. This prevents different reports from using conflicting definitions.

## Priority 5 — Use forecasts responsibly
Compare forecasting baselines on a held-out time period. Show MAE/RMSE and forecast horizon, and use replenishment suggestions as decision support rather than automatic purchasing instructions.

## Priority 6 — Build a controlled reporting workflow
Keep raw files access-controlled, separate raw data from derived outputs, log refresh dates, and record data-quality exceptions alongside dashboard metrics.
