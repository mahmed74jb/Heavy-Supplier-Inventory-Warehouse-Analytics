# Final QA Checklist

## Data and methods
- [ ] Expected CSVs and required columns are present.
- [ ] Key relationships and duplicate ID patterns are documented.
- [ ] Status labels and date ranges are validated.
- [ ] Delivered sales filters are consistently applied.
- [ ] Forecast backtest period and horizon are stated.
- [ ] KPI definitions match the calculations in code.
- [ ] Estimates are clearly labeled and not presented as audited financial values.

## Presentation
- [ ] Each slide has one main message.
- [ ] Every chart has a title, unit, time period, and source.
- [ ] Recommendations are linked to observed evidence or explicitly marked as proposed actions.
- [ ] Data limitations are visible, not hidden in footnotes.
- [ ] No unsupported claims of savings, ROI, or operational improvement.
- [ ] No raw sensitive data or unnecessary customer-level details are shown.

## Submission
- [ ] README and dependencies included.
- [ ] Code runs in a clean environment.
- [ ] Outputs can be regenerated from local source files.
- [ ] Raw dataset is excluded unless sharing is authorized.
