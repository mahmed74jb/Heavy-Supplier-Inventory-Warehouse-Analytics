# Week 10 — Final Analytics Presentation & Recommendations

This submission packages the final presentation outline, executive recommendations, and a reusable checklist for communicating the Heavy Supplier, Inventory & Warehouse Analytics project.

## Before running any analysis
The raw CSV data is intentionally not included. Copy the original project CSVs into `data/` locally if you plan to run the scripts or rebuild charts. Do not publish raw data publicly unless authorized.

## Contents
- `presentation/Final_Project_Story.md`: slide-by-slide presentation content
- `docs/Executive_Recommendations.md`: evidence-aware recommendations and limitations
- `docs/Final_QA_Checklist.md`: final review checklist
- `src/final_project_checks.py`: checks expected input files and writes a data inventory report
- `outputs/`: destination for generated reports

## Run
Install pandas with `pip install -r requirements.txt`, then run:
`python src/final_project_checks.py`

This week is focused on packaging and communication; it does not invent new metrics or claim unverified outcomes.
