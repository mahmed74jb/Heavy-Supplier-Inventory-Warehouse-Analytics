# Week 4 — Warehouse & Branch Efficiency Analytics

This submission contains the Week 4 analysis for the Heavy Supplier, Inventory & Warehouse Analytics project.

## Contents
- `notebooks/` — runnable Jupyter notebook
- `docs/` — report, sprint notes and upload guide
- `outputs/` — branch KPIs, stock flags, movement summary and data-quality checks

## Main focus
Branch operating indicators, warehouse capacity, delivered sales activity, inventory thresholds and stock movement.

## Important caveat
Current-stock values exceed max-stock values in the provided inventory snapshot. Validate the data definitions/units before treating this as confirmed overstock.
