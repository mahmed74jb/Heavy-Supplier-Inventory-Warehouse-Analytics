# Sprint 4 Notes — Warehouse & Branch Efficiency

## Goal
Review branch operating indicators, inventory threshold flags and stock-ledger movements.

## Completed
- Branch financial and capacity KPIs
- Delivered sales orders by branch
- Inventory threshold flags
- Stock movement summary
- Warehouse/branch data-quality checks

## KPI definitions
- Operating surplus = average monthly revenue − monthly operating cost
- Operating cost ratio = monthly operating cost / average monthly revenue
- Revenue per employee = average monthly revenue / employee count
- Delivered orders = distinct sales orders marked Delivered
- Inventory flags = comparisons of current stock with reorder, safety and max thresholds

## Limitation
Current-stock values exceed max-stock values in the supplied inventory snapshot. Validate source units/scale before interpreting these records as real overstock. Stock-ledger quantities should also be validated before turnover calculations.

## Individual project note
This work has been prepared individually and is structured for weekly GitHub submission.
