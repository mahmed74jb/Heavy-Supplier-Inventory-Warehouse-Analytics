# GitHub Upload Guide — Week 4

Inside your existing repository, add a folder named `week-04` and upload the contents of this submission into it.

```text
week-04/
├── README.md
├── notebooks/
│   └── Week4_Warehouse_Branch_Analytics.ipynb
├── docs/
│   ├── Week4_Report.md
│   ├── Sprint_4_Notes.md
│   └── GitHub_Upload_Guide.md
└── outputs/
    ├── branch_warehouse_kpis.csv
    ├── inventory_stock_snapshot.csv
    ├── inventory_stock_risk_flags.csv
    ├── stock_movement_summary.csv
    └── warehouse_data_quality_checks.csv
```

If the CadetX portal asks for a sprint number, use **4** for Week 4. Do not upload raw source data to a public repository unless CadetX has authorised public redistribution.
