# Week 4 Report — Warehouse & Branch Efficiency Analytics

## 1. Objective
Assess branch-level operating indicators, warehouse capacity, delivered sales activity, inventory snapshot risks and stock-ledger movement patterns.

## 2. Scope
- Branch revenue and operating cost
- Operating surplus and cost-to-revenue ratio
- Revenue per employee and per square foot (where capacity parses cleanly)
- Delivered order activity by branch
- Inventory records by branch and stock threshold flags
- Stock-ledger movement volumes
- Data-quality checks

## 3. Methods and KPI definitions
- **Monthly operating surplus** = average monthly revenue − monthly operational cost.
- **Operating cost % of revenue** = monthly operational cost ÷ average monthly revenue × 100.
- **Revenue per employee** = average monthly revenue ÷ total employees.
- **Revenue per sqft** = average monthly revenue ÷ parsed warehouse capacity in square feet.
- **Delivered orders** = count of distinct sales order IDs with `order_status = Delivered`.
- **Inventory above max** = `current_stock > max_stock`.
- **Below reorder** = `current_stock < reorder_level`.
- **At/below safety stock** = `current_stock <= safety_stock`.

These are descriptive KPIs, not audited financial or warehouse productivity measures.

## 4. Branch-level highlights

### Highest monthly operating surplus (based on supplied branch master values)
- Delhi Central (DEL001): monthly operating surplus 2,045,890
- Chennai South Hub (CHN001): monthly operating surplus 1,828,780
- Pune Distribution (PUN001): monthly operating surplus 1,735,120

### Highest average monthly revenue
- Delhi Central (DEL001): average monthly revenue 5,234,890
- Chennai South Hub (CHN001): average monthly revenue 4,567,780
- Pune Distribution (PUN001): average monthly revenue 4,389,120

See `outputs/branch_warehouse_kpis.csv` for all branch-level values.

## 5. Inventory threshold findings
- Inventory master contains **180** product-branch records.
- **180 / 180 (100.0%)** records have `current_stock` above `max_stock`.
- **0** records are below reorder level.
- **0** records are at or below safety stock.

**Important data-quality caveat:** the supplied current-stock values appear far larger than max-stock values across the inventory snapshot. Do not label these as confirmed overstock or make procurement changes until the source owner validates units, scale and field definitions. This issue was already identified in earlier project exploration.

## 6. Stock-ledger movement
`outputs/stock_movement_summary.csv` summarises movement counts and quantities by movement type. IN and OUT movements can indicate stock flow, but ledger quantity conventions should be validated before interpreting net quantity or calculating turnover.

## 7. Data quality
The branch-reference checks and inventory threshold checks are saved in `outputs/warehouse_data_quality_checks.csv`.

## 8. Recommendations
1. Validate `current_stock`, `max_stock`, `reorder_level` and `safety_stock` units/scales before acting on stock flags.
2. Compare branches using both financial indicators and operational context; higher revenue alone does not prove better warehouse efficiency.
3. Track delivered orders and stock movements by branch monthly.
4. Add space utilisation, pick/pack time, order fulfilment time, stockout days and labour hours if those data become available.
5. Reconcile stock-ledger balances against inventory snapshots before estimating inventory turnover.

## 9. Deliverables
- `notebooks/Week4_Warehouse_Branch_Analytics.ipynb`
- `outputs/branch_warehouse_kpis.csv`
- `outputs/inventory_stock_snapshot.csv`
- `outputs/inventory_stock_risk_flags.csv`
- `outputs/stock_movement_summary.csv`
- `outputs/warehouse_data_quality_checks.csv`
