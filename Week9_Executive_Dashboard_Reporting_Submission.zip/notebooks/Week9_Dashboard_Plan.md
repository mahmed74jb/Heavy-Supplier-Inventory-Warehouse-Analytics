# Week 9 Dashboard Plan

## Suggested page layout
1. **Executive overview:** delivered sales orders, delivered units, estimated sales value, inventory records, branch count.
2. **Inventory health:** records above max stock, stock by branch/category when dimensions are reliable, and data-quality warning.
3. **Procurement:** PO status distribution and estimated line value by supplier where supplier keys are available.
4. **Action list:** exceptions needing validation, high-value procurement categories, and next data-quality steps.

## KPI definitions
| KPI | Definition | Caveat |
|---|---|---|
| Delivered sales orders | Count of order headers with status Delivered | Status labels must be checked |
| Delivered units | Sum of line quantities attached to Delivered orders | Quantity units must be consistent |
| Estimated delivered sales value | Delivered line quantity × line unit price | Not necessarily net revenue; discounts/tax/returns may be absent |
| Inventory rows above max | Count where current stock > max stock | Source data contains a known anomaly; validate max-stock meaning |
| PO estimated value | PO line quantity × unit price | Not equivalent to payments or invoice value |
| PO status mix | Count of PO headers by status | Status definitions may differ by organization |

## Executive narrative template
- **What happened:** report delivered sales activity and procurement pipeline totals.
- **What needs attention:** highlight inventory rows above max stock and missing/invalid values.
- **What to do next:** validate stock limits, reconcile procurement value to invoices/payments, and confirm date fields before measuring supplier lead-time or on-time performance.

## QA checklist
- [ ] Confirm expected CSVs are present and headers match.
- [ ] Check duplicate IDs before joining; do not blindly drop repeated invoice/payment rows.
- [ ] Validate status categories and date ranges.
- [ ] Reconcile totals against source tables.
- [ ] Label estimates clearly and record assumptions.
- [ ] Do not present unavailable metrics as zero; identify missing data.
