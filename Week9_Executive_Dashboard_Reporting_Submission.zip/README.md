# Week 9 — Executive Dashboard & Reporting

## Goal
Create a repeatable executive reporting layer for Heavy Supplier, Inventory & Warehouse Analytics. This week consolidates sales, inventory, procurement, and branch metrics into clear KPI tables and charts.

## Setup
1. Copy the project CSV files into `data/` (the raw dataset is intentionally not included in this submission ZIP).
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python src/build_dashboard_data.py`
4. Outputs are written to `outputs/`.

## Data notes
- Sales metrics use only `Delivered` sales orders where a delivered status is available.
- Procurement value is an estimate (`quantity * unit_price`), not proof of paid or invoiced spend.
- The source inventory master has a known quality issue: current stock exceeds max stock in the supplied records. Review this before treating capacity or overstock KPIs as operational truth.
- This dataset does not establish supplier on-time delivery unless both promised and actual delivery dates are available.
- Do not publish raw data publicly unless you have authorization.

## Deliverables
- Reusable Python script for KPI generation
- KPI definitions and dashboard wireframe
- QA checklist and presentation notes
