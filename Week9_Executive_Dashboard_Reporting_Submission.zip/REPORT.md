# Week 9 — Executive Dashboard & Reporting Summary

## Objective
Turn prior analyses into an executive-ready KPI layer with reproducible outputs.

## Work completed
- Defined business-facing KPIs for delivered sales, inventory health, branches, and procurement.
- Added a reusable Python script that exports KPI tables and a snapshot chart.
- Documented definitions, assumptions, caveats, and validation steps.

## Important limitations
The script expects the raw CSVs to be placed in the local `data/` folder. Procurement values are estimates based on PO line quantity and unit price. Inventory values above maximum stock are flagged for review rather than automatically classified as errors. Supplier on-time performance should not be claimed without reliable promised and actual receipt dates.

## Next sprint
Build a stakeholder-facing dashboard (e.g., Power BI or Tableau) from the generated CSV outputs, add validated trend dimensions, and review KPI definitions with the project mentor.
