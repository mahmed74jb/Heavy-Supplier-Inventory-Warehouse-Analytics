from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def load(name):
    path = DATA / name
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. Copy the raw CSV files into the data/ folder.")
    return pd.read_csv(path)

def main():
    sales_h = load("sales_orders_header.csv")
    sales_l = load("sales_orders_lines.csv")
    inv = load("inventory_master.csv")
    po_h = load("purchase_orders_header.csv")
    po_l = load("purchase_orders_lines.csv")
    branches = load("branches.csv")

    # Normalize column lookup to tolerate capitalization differences.
    def col(df, candidates):
        lookup = {c.lower().replace(" ", "_"): c for c in df.columns}
        for c in candidates:
            key = c.lower().replace(" ", "_")
            if key in lookup:
                return lookup[key]
        return None

    status = col(sales_h, ["status", "order_status"])
    order_id_h = col(sales_h, ["sales_order_id", "order_id", "id"])
    order_id_l = col(sales_l, ["sales_order_id", "order_id"])
    qty_l = col(sales_l, ["quantity", "qty", "order_quantity"])
    price_l = col(sales_l, ["unit_price", "price", "selling_price"])
    if not all([status, order_id_h, order_id_l, qty_l]):
        raise ValueError("Could not identify required sales columns. Check CSV headers.")

    delivered = sales_h[sales_h[status].astype(str).str.lower().eq("delivered")].copy()
    delivered_ids = set(delivered[order_id_h].astype(str))
    sales_l[order_id_l] = sales_l[order_id_l].astype(str)
    delivered_lines = sales_l[sales_l[order_id_l].isin(delivered_ids)].copy()
    delivered_lines["quantity_num"] = pd.to_numeric(delivered_lines[qty_l], errors="coerce").fillna(0)
    if price_l:
        delivered_lines["value_estimate"] = delivered_lines["quantity_num"] * pd.to_numeric(delivered_lines[price_l], errors="coerce").fillna(0)
    else:
        delivered_lines["value_estimate"] = 0

    inventory_qty = col(inv, ["current_stock", "stock_quantity", "quantity_on_hand"])
    max_qty = col(inv, ["max_stock", "maximum_stock"])
    if inventory_qty:
        inv[inventory_qty] = pd.to_numeric(inv[inventory_qty], errors="coerce")
    if max_qty:
        inv[max_qty] = pd.to_numeric(inv[max_qty], errors="coerce")

    po_qty = col(po_l, ["quantity", "qty", "ordered_quantity"])
    po_price = col(po_l, ["unit_price", "price", "cost"])
    po_status = col(po_h, ["status", "po_status", "purchase_order_status"])

    kpis = [
        ("Delivered sales orders", len(delivered)),
        ("Delivered sales lines", len(delivered_lines)),
        ("Delivered units", float(delivered_lines["quantity_num"].sum())),
        ("Estimated delivered sales value", float(delivered_lines["value_estimate"].sum())),
        ("Inventory records", len(inv)),
        ("Branches", len(branches)),
        ("Purchase order headers", len(po_h)),
    ]
    if inventory_qty and max_qty:
        kpis.append(("Inventory rows above max stock", int((inv[inventory_qty] > inv[max_qty]).sum())))
    pd.DataFrame(kpis, columns=["kpi", "value"]).to_csv(OUT / "executive_kpis.csv", index=False)

    if po_qty and po_price:
        po_l["qty_num"] = pd.to_numeric(po_l[po_qty], errors="coerce").fillna(0)
        po_l["price_num"] = pd.to_numeric(po_l[po_price], errors="coerce").fillna(0)
        po_l["estimated_line_value"] = po_l["qty_num"] * po_l["price_num"]
        po_l[["qty_num", "price_num", "estimated_line_value"]].describe().to_csv(OUT / "procurement_summary.csv")
    if po_status:
        po_h[po_status].fillna("Unknown").value_counts().rename_axis("status").reset_index(name="count").to_csv(OUT / "purchase_order_status.csv", index=False)

    # Simple chart suitable for the executive dashboard.
    labels = [x[0] for x in kpis[:6]]
    values = [x[1] for x in kpis[:6]]
    plt.figure(figsize=(10, 5))
    plt.bar(labels, values)
    plt.xticks(rotation=25, ha="right")
    plt.title("Executive KPI Snapshot")
    plt.tight_layout()
    plt.savefig(OUT / "executive_kpi_snapshot.png", dpi=160)
    plt.close()
    print(f"Dashboard data written to {OUT}")

if __name__ == "__main__":
    main()
