# Week 2 Report — Product & Inventory Analytics

## Sprint Goal
Analyse product performance, fast/slow movement, inventory-health diagnostics, and product demand trends.

## Method
Only **Delivered** sales orders are treated as realised product movement. Cancelled orders are excluded.

Fast/slow movement is defined using quartiles among products with delivered sales:
- Fast-moving: units sold >= 75th percentile
- Slow-moving: units sold > 0 and <= 25th percentile
- No delivered sales: units sold = 0
- Normal-moving: remaining products

These are analytical thresholds for Sprint 2, not permanent business rules.

## Results
- Total products: **30**
- Products with delivered sales: **30**
- Products with no delivered sales: **0**
- Fast-moving products: **8**
- Slow-moving products: **8**
- Delivered units sold: **1,234,939**
- Delivered sales value: **29,253,993,162.40**

## Top 10 Products by Delivered Sales Value

| Rank | Product | Category | Units Sold | Sales Value |
|---:|---|---|---:|---:|
| 1 | Engine Block EB-600 | Engine | 40,815 | 6,216,940,800.00 |\n| 2 | Transmission Assembly TA-800 | Transmission | 40,574 | 4,336,549,120.00 |\n| 3 | Boom Cylinder BC-400 | Hydraulic | 41,864 | 2,475,669,504.00 |\n| 4 | Swing Motor SWM-350 | Hydraulic | 41,543 | 2,116,366,592.00 |\n| 5 | Track Chain TC-45 | Undercarriage | 40,891 | 2,083,151,104.00 |\n| 6 | Turbocharger TB-900 | Engine | 42,292 | 1,889,268,224.00 |\n| 7 | Hydraulic Cylinder HC-200 | Hydraulic | 42,093 | 1,487,061,504.00 |\n| 8 | Hydraulic Pump HP-300 | Hydraulic | 41,304 | 1,295,293,440.00 |\n| 9 | Fuel Pump FP-350 | Engine | 41,595 | 1,165,991,040.00 |\n| 10 | Control Valve CV-75 | Hydraulic | 41,297 | 893,336,704.00 |\n
## Inventory Health Diagnostic

Week 1 identified that `current_stock` is above `max_stock` for all **180** inventory records. This remains a data-validation issue.

Therefore, this sprint **does not claim that all products are genuinely overstocked**. Stock/max ratios are diagnostic only until the data owner confirms the unit and scale of `current_stock`.

- Current stock > max stock: **180**
- Current stock < reorder level: **0**
- Current stock < safety stock: **0**

## Slow / No-Sales Products

The complete list is in `outputs/slow_and_no_sales_products.csv`.

Low/no sales should not automatically be labelled dead stock. Product age, seasonality, branch availability and inventory age should be considered in later analysis.

## Demand Trends

Monthly product demand is available in `outputs/monthly_product_demand.csv`, calculated from delivered sales-order lines. It is a foundation for later forecasting.

## Week 2 Conclusions

1. Realised product movement can be measured from delivered sales.
2. Fast and slow movers are now classified with a reproducible method.
3. Low/no-sales products have been identified for further investigation.
4. Monthly product demand is prepared for future forecasting.
5. Inventory optimisation remains conditional on resolving the `current_stock` scale issue.

## Week 3 Handoff

Next sprint should complete reusable data integration, feature engineering and business-rule validation so the dataset is ready for deeper product, inventory and warehouse analytics.
