# Sprint 2 Notes

## Sprint Goal
Build the first product and inventory analytics layer.

## Completed
- Product performance
- Fast-moving product identification
- Slow-moving/no-sales identification
- Inventory health diagnostics
- Monthly demand trend preparation
- Category performance
- Documentation and outputs

## Key Data Rule
Delivered sales orders are used as realised product movement.

## Important Data-Quality Risk
`current_stock > max_stock` remains a validation issue from Week 1. It is not treated as confirmed overstock.

## Next Sprint
Complete data integration and feature engineering for the clean analytical dataset.
