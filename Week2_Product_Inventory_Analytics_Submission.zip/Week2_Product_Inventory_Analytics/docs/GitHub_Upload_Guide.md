# GitHub Upload Guide — Sprint 2

In your existing repository, create the folder:

`week-02/`

Upload:
- README.md
- notebooks/Week2_Product_Inventory_Analytics.ipynb
- docs/Week2_Report.md
- docs/Sprint_2_Notes.md
- outputs/product_inventory_analysis.csv
- outputs/top_20_products_by_sales.csv
- outputs/top_20_fast_movers.csv
- outputs/slow_and_no_sales_products.csv
- outputs/monthly_product_demand.csv
- outputs/category_performance.csv
- outputs/inventory_health_summary.csv

If the dataset is not authorised for public redistribution, do not upload raw CSVs to a public GitHub repository.
