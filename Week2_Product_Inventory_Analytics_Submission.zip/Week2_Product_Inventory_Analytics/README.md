# Week 2 — Product & Inventory Analytics

CadetX Heavy Supplier, Inventory & Warehouse Analytics — Sprint 2.

## Included
Product performance, fast/slow movers, no-sales products, inventory diagnostics, demand trends, category analysis, notebook, report and sprint notes.

## Method
Delivered sales orders are treated as realised movement. Fast/slow thresholds use the 75th and 25th percentiles of units sold among products with delivered sales.

## Data-quality note
The `current_stock > max_stock` issue remains under validation, so stock/max ratios are diagnostic only.
