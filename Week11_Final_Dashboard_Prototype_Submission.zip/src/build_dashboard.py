from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def load(name):
    p = DATA / name
    if not p.exists():
        raise FileNotFoundError(f"Missing {p}. Copy the original CSV files into data/.")
    return pd.read_csv(p)

def choose(df, *names):
    cols = {c.lower().replace(" ", "_"): c for c in df.columns}
    for name in names:
        key = name.lower().replace(" ", "_")
        if key in cols:
            return cols[key]
    return None

def main():
    sales_h = load("sales_orders_header.csv")
    sales_l = load("sales_orders_lines.csv")
    inv = load("inventory_master.csv")
    po_h = load("purchase_orders_header.csv")
    po_l = load("purchase_orders_lines.csv")
    branches = load("branches.csv")

    status = choose(sales_h, "status", "order_status")
    hid = choose(sales_h, "sales_order_id", "order_id", "id")
    lid = choose(sales_l, "sales_order_id", "order_id")
    qty = choose(sales_l, "quantity", "qty", "order_quantity")
    price = choose(sales_l, "unit_price", "price", "selling_price")
    if not all([status, hid, lid, qty]):
        raise ValueError("Required sales columns not detected; inspect CSV headers.")

    delivered = sales_h[sales_h[status].astype(str).str.lower().eq("delivered")]
    delivered_ids = set(delivered[hid].astype(str))
    sales_l[lid] = sales_l[lid].astype(str)
    lines = sales_l[sales_l[lid].isin(delivered_ids)].copy()
    lines["qty_numeric"] = pd.to_numeric(lines[qty], errors="coerce").fillna(0)
    lines["estimated_value"] = lines["qty_numeric"] * (
        pd.to_numeric(lines[price], errors="coerce").fillna(0) if price else 0
    )

    stock = choose(inv, "current_stock", "stock_quantity", "quantity_on_hand")
    max_stock = choose(inv, "max_stock", "maximum_stock")
    above_max = None
    if stock and max_stock:
        above_max = int((
            pd.to_numeric(inv[stock], errors="coerce") >
            pd.to_numeric(inv[max_stock], errors="coerce")
        ).sum())

    kpis = [
        ("Delivered sales orders", len(delivered)),
        ("Delivered sales lines", len(lines)),
        ("Delivered units", float(lines["qty_numeric"].sum())),
        ("Estimated delivered sales value", float(lines["estimated_value"].sum())),
        ("Inventory records", len(inv)),
        ("Branches", len(branches)),
        ("Purchase order headers", len(po_h)),
    ]
    if above_max is not None:
        kpis.append(("Inventory rows above max stock", above_max))
    pd.DataFrame(kpis, columns=["kpi", "value"]).to_csv(OUT / "dashboard_kpis.csv", index=False)

    po_qty = choose(po_l, "quantity", "qty", "ordered_quantity")
    po_price = choose(po_l, "unit_price", "price", "cost")
    if po_qty and po_price:
        po_l["estimated_value"] = (
            pd.to_numeric(po_l[po_qty], errors="coerce").fillna(0) *
            pd.to_numeric(po_l[po_price], errors="coerce").fillna(0)
        )
        pd.DataFrame([{
            "purchase_order_lines": len(po_l),
            "estimated_procurement_value": float(po_l["estimated_value"].sum())
        }]).to_csv(OUT / "procurement_kpis.csv", index=False)

    plt.figure(figsize=(9, 4.5))
    plt.bar([k[0] for k in kpis], [k[1] for k in kpis])
    plt.xticks(rotation=28, ha="right")
    plt.title("Dashboard KPI Snapshot")
    plt.tight_layout()
    plt.savefig(OUT / "dashboard_kpis.png", dpi=150)
    plt.close()
    print(f"Created KPI outputs in {OUT}")

if __name__ == "__main__":
    main()
