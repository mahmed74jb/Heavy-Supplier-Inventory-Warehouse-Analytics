# Week 11 — Dashboard Prototype & Final Validation

This week's package provides a lightweight interactive dashboard prototype and a final validation checklist for the Heavy Supplier, Inventory & Warehouse Analytics project.

## Setup
1. Copy the authorized raw CSV files into `data/` (not included in this ZIP).
2. Install dependencies: `pip install -r requirements.txt`
3. Generate summary outputs: `python src/build_dashboard.py`
4. Open `dashboard/index.html` in a browser to view the static prototype. For current values, regenerate the outputs first.

## Important
The prototype is a presentational mockup and does not automatically load the CSV outputs into the browser. The Python script creates reusable KPI CSVs and a chart; use Power BI/Tableau or connect a reviewed data layer for a fully dynamic dashboard.

Do not publish raw source data publicly unless authorized.
