# Week 11 — Final Validation Checklist

- [ ] CSV inputs are the authorized project files and are stored locally in `data/`.
- [ ] Column names, row grain, primary keys, and join keys are documented.
- [ ] Delivered order filter is consistent across all sales metrics.
- [ ] Estimated sales and procurement values are labeled as estimates.
- [ ] Inventory current-stock/max-stock anomaly is reviewed with the data owner.
- [ ] Supplier on-time delivery is not claimed without validated promised/actual dates.
- [ ] Repeated invoice/payment IDs are understood before any deduplication.
- [ ] Charts show units, dates, filters, and data source.
- [ ] Dashboard refresh date and KPI owner are documented.
- [ ] No raw data or customer-sensitive detail is included in public artifacts.
- [ ] Python script runs from a clean environment and outputs are reproducible.
