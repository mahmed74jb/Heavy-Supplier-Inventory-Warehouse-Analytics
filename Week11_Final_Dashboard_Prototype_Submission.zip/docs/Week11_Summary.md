# Week 11 Summary

## Objective
Provide a final dashboard prototype and validate that the project can be presented with clear, cautious KPI definitions.

## Deliverables
- HTML dashboard wireframe
- Python KPI export script
- Validation checklist
- Setup notes and data caveats

## Limitations
The HTML dashboard is a prototype with placeholder KPI values. It does not dynamically read CSV files. Run the Python script to create KPI CSVs and a PNG chart; connect these outputs to an approved BI/reporting layer to make a live dashboard. The raw dataset is intentionally excluded from this ZIP.
