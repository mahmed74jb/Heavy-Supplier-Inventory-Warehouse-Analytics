# Final Submission Checklist

- [ ] README explains setup and data requirements.
- [ ] Required source CSVs are present locally and authorized for use.
- [ ] Script runs successfully from a clean environment.
- [ ] Output report is reviewed for missing files and read errors.
- [ ] KPI formulas and filters match the final presentation.
- [ ] Financial estimates are clearly distinguished from actual invoice/payment totals.
- [ ] Forecast metrics state model, horizon, and test period.
- [ ] Inventory max-stock exception is documented.
- [ ] Supplier on-time metrics are omitted unless dates are validated.
- [ ] Presentation uses readable charts with units, periods, and sources.
- [ ] No unsupported savings or ROI claims.
- [ ] Raw customer or supplier-sensitive data is not shared publicly.
