from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

EXPECTED = [
    "branches.csv", "customers.csv", "inventory_master.csv", "invoices.csv",
    "payments.csv", "products.csv", "purchase_orders_header.csv",
    "purchase_orders_lines.csv", "sales_orders_header.csv",
    "sales_orders_lines.csv", "stock_ledger.csv", "suppliers.csv"
]

def main():
    results = []
    for name in EXPECTED:
        path = DATA / name
        if not path.exists():
            results.append({
                "file": name, "status": "MISSING",
                "rows": None, "columns": None, "notes": "Copy authorized source CSV into data/"
            })
            continue
        try:
            df = pd.read_csv(path)
            results.append({
                "file": name, "status": "OK",
                "rows": len(df), "columns": len(df.columns), "notes": ""
            })
        except Exception as exc:
            results.append({
                "file": name, "status": "READ_ERROR",
                "rows": None, "columns": None, "notes": str(exc)
            })
    report = pd.DataFrame(results)
    report.to_csv(OUT / "final_validation_report.csv", index=False)
    print(report.to_string(index=False))
    print(f"\\nSaved report: {OUT / 'final_validation_report.csv'}")

if __name__ == "__main__":
    main()
