# Week 12 — Final Project Submission

This is the final consolidation package for the Heavy Supplier, Inventory & Warehouse Analytics project. It brings together reproducibility checks, project documentation, final recommendations, and a presentation checklist.

## Run locally
1. Copy the authorized source CSV files into `data/`. Raw data is intentionally excluded from this ZIP.
2. Install dependencies: `pip install -r requirements.txt`
3. Run `python src/final_validation.py`
4. Review `outputs/final_validation_report.csv`.

## Included
- Final project summary and limitations
- Reproducibility/validation script
- Submission and presentation checklist
- Executive handover notes

## Important caveats
- Procurement line value calculated as quantity × unit price is an estimate, not confirmed paid/invoiced spend.
- The supplied inventory master previously showed current stock above max stock across its records; verify the business rule and source values before treating this as confirmed overstock.
- Supplier on-time delivery cannot be established without reliable promised and actual receipt dates.
- Repeated invoice/payment IDs should not be blindly deduplicated; first confirm row grain and intended relationships.
- Do not publish raw data publicly unless authorized.
