from pathlib import Path
import pandas as pd
import numpy as np

DATA_DIR=Path("../data")
OUT=Path("../outputs"); OUT.mkdir(parents=True,exist_ok=True)
def load(n):
    p=DATA_DIR/n
    if not p.exists(): raise FileNotFoundError(f"Copy CSV files into {DATA_DIR.resolve()}")
    return pd.read_csv(p)
sup=load("suppliers.csv"); poh=load("purchase_orders_header.csv"); pol=load("purchase_orders_lines.csv")
def pick(df, opts, required=True):
    c=next((x for x in opts if x in df.columns),None)
    if c is None and required: raise KeyError(f"Missing one of {opts}; columns={list(df.columns)}")
    return c
sk=pick(sup,["supplier_id","supplier_code"]); psk=pick(poh,["supplier_id","supplier_code"])
pk=pick(poh,["po_id","purchase_order_id"]); lpk=pick(pol,["po_id","purchase_order_id"])
qk=pick(pol,["quantity","ordered_qty","order_qty"],False); uk=pick(pol,["unit_price","price"],False)
status=pick(poh,["status","po_status","order_status"],False)
date=pick(poh,["order_date","po_date","created_date"],False)
pol=pol.copy()
if qk and uk:
    pol["_qty"]=pd.to_numeric(pol[qk],errors="coerce"); pol["_price"]=pd.to_numeric(pol[uk],errors="coerce")
    pol["_value"]=pol["_qty"]*pol["_price"]
else:
    pol["_value"]=np.nan
if "_qty" in pol:
    lm=pol.groupby(lpk,as_index=False).agg(line_count=(lpk,"size"),estimated_line_value=("_value","sum"),total_ordered_qty=("_qty","sum"))
else:
    lm=pol.groupby(lpk,as_index=False).agg(line_count=(lpk,"size"),estimated_line_value=("_value","sum"))
pm=poh.merge(lm,left_on=pk,right_on=lpk,how="left")
skpi=pm.groupby(psk,as_index=False).agg(purchase_order_count=(pk,"nunique"),total_estimated_procurement_value=("estimated_line_value","sum"),total_po_line_count=("line_count","sum"))
if status:
    sc=pd.crosstab(pm[psk],pm[status].fillna("Missing")).reset_index()
    skpi=skpi.merge(sc,on=psk,how="left")
skpi=sup.merge(skpi,left_on=sk,right_on=psk,how="left")
skpi["purchase_order_count"]=skpi["purchase_order_count"].fillna(0).astype(int)
skpi["total_estimated_procurement_value"]=skpi["total_estimated_procurement_value"].fillna(0)
skpi.to_csv(OUT/"supplier_performance_scorecard.csv",index=False)
if date:
    pm["_date"]=pd.to_datetime(pm[date],errors="coerce"); pm["_month"]=pm["_date"].dt.to_period("M").dt.to_timestamp()
    pm.groupby("_month").agg(purchase_orders=(pk,"nunique"),estimated_procurement_value=("estimated_line_value","sum")).to_csv(OUT/"monthly_procurement_trend.csv")
print("Week 8 supplier/procurement outputs saved to",OUT.resolve())
