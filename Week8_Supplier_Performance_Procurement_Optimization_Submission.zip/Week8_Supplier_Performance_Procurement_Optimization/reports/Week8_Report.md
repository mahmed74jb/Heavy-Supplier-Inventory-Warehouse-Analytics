# Week 8 Report — Supplier Performance & Procurement Optimization

## Objective
Build a supplier procurement scorecard, summarize purchase-order activity, and identify data limitations that affect supplier performance decisions.

## Data used
Supplier master, purchase order headers, purchase order lines, product master, and inventory master.

## Method
- Check supplier and PO key relationships for unmatched references and duplicate keys.
- Estimate procurement line value as ordered quantity × unit price when both fields are available.
- Aggregate PO count, PO-line count, and estimated procurement value by supplier.
- Summarize PO statuses and monthly procurement value when status/date columns are available.
- Calculate supplier value share and cumulative concentration.
- Check inventory stock-vs-maximum values as a contextual data-quality issue.

## Important limitations
Estimated PO-line value is not necessarily invoiced or paid value. Supplier on-time delivery and quality performance cannot be measured reliably unless the data includes actual versus promised delivery dates and quality/defect measures. Inventory `current_stock > max_stock` appears in 180 of 180 records, so stock-related decisions need validation.

## Recommendations
- Reconcile estimated procurement value against invoices and payments.
- Use supplier concentration to identify potential dependency risk.
- Add delivery timeliness, defect rate, return rate, and lead-time variability to the scorecard if those fields become available.
- Validate supplier master keys and procurement status definitions before operational reporting.
