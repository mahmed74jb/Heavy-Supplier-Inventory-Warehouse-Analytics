# CadetX Sprint 8 Submission Notes

**Sprint title:** Supplier Performance & Procurement Optimization

## Completed
- Supplier and PO relationship checks
- Supplier-level PO count and estimated procurement value
- PO status summaries and monthly procurement trend where dates are available
- Supplier spend concentration view
- Inventory data-quality context and limitations

## Upload checklist
- [ ] Extract the ZIP.
- [ ] Upload folder contents to existing GitHub repository under `week-08/`.
- [ ] Keep notebook, report, README, script, and requirements together.
- [ ] Do not upload raw dataset publicly unless authorized.
- [ ] Submit repository link in CadetX and select Sprint/Week 8.
