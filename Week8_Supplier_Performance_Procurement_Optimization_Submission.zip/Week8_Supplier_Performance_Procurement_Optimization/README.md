# Week 8 — Supplier Performance & Procurement Optimization

## Included
- Main Jupyter notebook
- Reusable Python analysis script
- Week 8 report
- Sprint notes and requirements

## Run
1. Extract the original dataset ZIP privately.
2. Copy CSV files into `data/`.
3. Run `pip install -r requirements.txt`.
4. Open the notebook and run it top to bottom.

The source dataset is not included to avoid public redistribution without permission.
